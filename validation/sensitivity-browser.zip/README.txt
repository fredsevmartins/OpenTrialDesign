OpenTrialDesign reproducibility bundle
CSV values are unrounded computational outputs.
project.json (when present) is the non-executable replay configuration.
result.rds is an R object for trusted local archival; never import untrusted RDS files.
manifest.csv records MD5 integrity checks, not cryptographic authenticity.
