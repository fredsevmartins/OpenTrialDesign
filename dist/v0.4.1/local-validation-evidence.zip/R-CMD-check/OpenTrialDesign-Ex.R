pkgname <- "OpenTrialDesign"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
library('OpenTrialDesign')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
base::assign(".old_wd", base::getwd(), pos = 'CheckExEnv')
cleanEx()
nameEx("adaptive_simulation")
### * adaptive_simulation

flush(stderr()); flush(stdout())

### Name: adaptive_simulation
### Title: Simulate a two-stage adaptive inverse-normal combination test
### Aliases: adaptive_simulation

### ** Examples

if (requireNamespace("rpact", quietly = TRUE)) adaptive_simulation(nsim = 100)



cleanEx()
nameEx("means_design")
### * means_design

flush(stderr()); flush(stdout())

### Name: means_design
### Title: Plan or evaluate unequal-allocation normal superiority,
###   noninferiority or equivalence
### Aliases: means_design

### ** Examples

if (requireNamespace("rpact",quietly=TRUE)) means_design(allocation_ratio=2)



cleanEx()
nameEx("review_project")
### * review_project

flush(stderr()); flush(stdout())

### Name: review_project
### Title: Describe the scientific contract before executing a project
### Aliases: review_project

### ** Examples

review_project(trial_project())



cleanEx()
nameEx("run_example")
### * run_example

flush(stderr()); flush(stdout())

### Name: run_example
### Title: Execute a documented scientific example
### Aliases: run_example

### ** Examples

run_example("TD-001")



cleanEx()
nameEx("sample_size")
### * sample_size

flush(stderr()); flush(stdout())

### Name: sample_size
### Title: Calculate fixed sample size
### Aliases: sample_size

### ** Examples

sample_size(trial_spec(effect = 0.5))



cleanEx()
nameEx("scenario_grid")
### * scenario_grid

flush(stderr()); flush(stdout())

### Name: scenario_grid
### Title: Expand a project's assumptions into a reproducible sensitivity
###   grid
### Aliases: scenario_grid

### ** Examples

projects <- scenario_grid(trial_project(), list(effect=c(.3,.5), power=c(.8,.9)))
run_scenarios(projects)$data$summary



cleanEx()
nameEx("sequential_design")
### * sequential_design

flush(stderr()); flush(stdout())

### Name: sequential_design
### Title: Create a one-sided group sequential design
### Aliases: sequential_design

### ** Examples

if (requireNamespace("gsDesign", quietly = TRUE)) sequential_design()



cleanEx()
nameEx("sequential_sample_size")
### * sequential_sample_size

flush(stderr()); flush(stdout())

### Name: sequential_sample_size
### Title: Plan integer-enrollment sequential normal means using rpact
### Aliases: sequential_sample_size

### ** Examples

if (requireNamespace("rpact", quietly = TRUE)) sequential_sample_size()



cleanEx()
nameEx("simulate_nonph")
### * simulate_nonph

flush(stderr()); flush(stdout())

### Name: simulate_nonph
### Title: Evaluate piecewise exponential nonproportional hazards with
###   native rpact simulation
### Aliases: simulate_nonph

### ** Examples

if(requireNamespace("rpact",quietly=TRUE)) simulate_nonph(nsim=20)



cleanEx()
nameEx("simulate_survival")
### * simulate_survival

flush(stderr()); flush(stdout())

### Name: simulate_survival
### Title: Simulate survival trial operating characteristics
### Aliases: simulate_survival

### ** Examples

if (requireNamespace("simsurv", quietly = TRUE))
  simulate_survival(50, nsim = 10, seed = 42)



cleanEx()
nameEx("simulate_trial")
### * simulate_trial

flush(stderr()); flush(stdout())

### Name: simulate_trial
### Title: Estimate operating characteristics with Monte Carlo uncertainty
### Aliases: simulate_trial

### ** Examples

simulate_trial(trial_spec(), 64, nsim = 100, seed = 42)



cleanEx()
nameEx("survival_design")
### * survival_design

flush(stderr()); flush(stdout())

### Name: survival_design
### Title: Plan an exponential proportional hazards survival trial
### Aliases: survival_design

### ** Examples

if (requireNamespace("rpact", quietly = TRUE)) survival_design()



cleanEx()
nameEx("trial_power")
### * trial_power

flush(stderr()); flush(stdout())

### Name: trial_power
### Title: Calculate analytical power at an integer sample size
### Aliases: trial_power

### ** Examples

trial_power(trial_spec(), 64)



cleanEx()
nameEx("trial_project")
### * trial_project

flush(stderr()); flush(stdout())

### Name: trial_project
### Title: Create a portable, non-executable trial project
### Aliases: trial_project

### ** Examples

p <- trial_project("fixed_sample_size", list(effect = 0.5), "Normal trial")
execute_project(p)



cleanEx()
nameEx("trial_spec")
### * trial_spec

flush(stderr()); flush(stdout())

### Name: trial_spec
### Title: Specify a fixed sample superiority trial
### Aliases: trial_spec

### ** Examples

trial_spec(effect = 0.5)



### * <FOOTER>
###
cleanEx()
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
