## ----setup--------------------------------------------------------------------
library(OpenTrialDesign)

## ----fixed--------------------------------------------------------------------
spec <- trial_spec(effect = 0.5, sd = 1, alpha = 0.05, power = 0.8)
sample_size(spec)
trial_power(spec, 64)

## ----binary-------------------------------------------------------------------
binary <- trial_spec("binary", effect = 0.15, p_control = 0.3)
sample_size(binary)
compare_scenarios(list(base = spec, smaller_effect = trial_spec(effect = 0.3)))

## ----simulation---------------------------------------------------------------
simulate_trial(spec, 64, nsim = 200, seed = 2026)
simulate_trial(spec, 64, nsim = 200, seed = 2026, null = TRUE)

## ----sequential---------------------------------------------------------------
if (requireNamespace("gsDesign", quietly = TRUE)) {
  seq_design <- sequential_design(information = c(0.33, 0.67, 1),
                                  futility = "nonbinding")
  print(seq_design)
  plot_design(seq_design)
  sequential_power(seq_design, theta = 0)
  conditional_power(seq_design, z = 1.5)
  simulate_sequential(seq_design, nsim = 200, seed = 2026)
}

## ----adaptive-----------------------------------------------------------------
if (requireNamespace("rpact", quietly = TRUE)) {
  adaptive <- adaptive_simulation(nsim = 200, seed = 2026)
  print(adaptive)
}

## ----survival-----------------------------------------------------------------
if (requireNamespace("rpact", quietly = TRUE)) {
  surv_design <- survival_design(hazard_ratio = 0.7, median_control = 12,
    accrual = 18, followup = 12, dropout = 0.1)
  print(surv_design$data$native)
}
if (requireNamespace("simsurv", quietly = TRUE)) {
  simulate_survival(100, events = 120, nsim = 20, seed = 2026)
}

## ----diagnostics--------------------------------------------------------------
diagnose_design(simulate_trial(spec, 64, nsim = 50, seed = 2026))

## ----projects-----------------------------------------------------------------
project <- trial_project("fixed_sample_size", list(effect = 0.5), "Demonstration")
execute_project(project)

## ----sequential-enrollment----------------------------------------------------
if (requireNamespace("rpact", quietly=TRUE)) sequential_sample_size()

## -----------------------------------------------------------------------------
projects <- scenario_grid(trial_project(),
  list(effect=c(.3,.5),power=c(.8,.9)))
comparison <- run_scenarios(projects)
comparison$data$summary

## -----------------------------------------------------------------------------
sparse <- trial_spec("binary",effect=.005,p_control=.01)
binary_diagnostics(sparse,10,null=TRUE)

## -----------------------------------------------------------------------------
if(requireNamespace("rpact",quietly=TRUE)){
  ni <- means_design(allocation_ratio=2,margin=.3,effect=0)
  ni$data[c("n_control","n_treatment","rejection_probability")]
}
if(requireNamespace("PowerTOST",quietly=TRUE)){
  eq <- means_design(hypothesis="equivalence",effect=.02,lower=-.2,upper=.4,allocation_ratio=2)
  eq$data[c("n_control","n_treatment","rejection_probability")]
}

## ----eval=FALSE---------------------------------------------------------------
# simulate_nonph(times=c(0,6),lambda_control=c(.06,.06),
#   lambda_treatment=c(.08,.03),n_total=240,events=100,
#   allocation_treatment=2,allocation_control=1,nsim=1000,seed=42)

